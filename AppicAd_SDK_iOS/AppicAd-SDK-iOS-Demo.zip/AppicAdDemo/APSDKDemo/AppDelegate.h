//
//  AppDelegate.h
//  AffiliateSDKSample
//
//  Created by Jason Y Liu on 5/11/16.
//  Copyright © 2016 Jason Y Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

#define abcabcabc @"abc_abc"

#define abc @"abc"

#define abc_macro(param) abc##param##abc

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

