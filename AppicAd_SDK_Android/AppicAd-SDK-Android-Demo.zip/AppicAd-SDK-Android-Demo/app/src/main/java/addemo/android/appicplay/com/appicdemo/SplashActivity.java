package addemo.android.appicplay.com.appicdemo;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.ap.android.trunk.sdk.ad.listener.APAdSplashListener;
import com.ap.android.trunk.sdk.ad.splash.APAdSplash;
import com.ap.android.trunk.sdk.ad.utils.APAdError;

import addemo.android.appicplay.com.appicdemo.utils.DemoHelper;


public class SplashActivity extends Activity implements View.OnClickListener, RadioGroup.OnCheckedChangeListener {

    private static final String TAG = "SplashActivity";

    private APAdSplash splash;
    private Button loadBtn;
    private Button showBtn;
    private RadioGroup rgModes;
    private CheckBox cb;
    private LinearLayout splashContainer;
    private View bottomView;
    private static final int SPLASH_TIME_OUT = 10; // 秒
    private static final int SPLASH_SHOW_INTERVAL = 5; // 秒
    private boolean isAutofit = true;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DemoHelper.setFullScreen(this);
        setContentView(R.layout.splash);
        initView();
    }


    private void initView() {
        splashContainer = findViewById(R.id.splashContainer);
        bottomView = getLayoutInflater().inflate(R.layout.splash_bottom, null);
        loadBtn = findViewById(R.id.load);
        showBtn = findViewById(R.id.show);
        rgModes = findViewById(R.id.rgModes);
        cb = findViewById(R.id.autofit);
        loadBtn.setOnClickListener(this);
        showBtn.setOnClickListener(this);
        rgModes.setOnCheckedChangeListener(this);
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                isAutofit = isChecked;
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.load:
                loadSplash();
                break;
            case R.id.show:
                showSplash();
                break;
        }
    }


    private void loadSplash() {

        if (splash != null) {
            splash = null;
            splashContainer.removeAllViews();
        }

        splash = new APAdSplash(Config.SPLASH_SLOT_ID, new APAdSplashListener() {
            @Override
            public void onAPAdSplashLoadSuccess(APAdSplash ad) {
                Log.d(TAG, "开屏广告加载成功");
                showToast("开屏广告加载成功");

            }

            @Override
            public void onAPAdSplashLoadFail(APAdSplash apAdSplash, APAdError apAdError) {
                Log.e(TAG, "加载失败：" + apAdError.getCode() + ",msg:" + apAdError.getMsg());
                showToast("加载失败 ： " + apAdError.getMsg());


            }

            @Override
            public void onAPAdSplashDidAssembleViewFail(APAdSplash apAdSplash, APAdError apAdError) {
                Log.e(TAG, "构建失败：" + apAdError.getCode() + ",msg:" + apAdError.getMsg());
                showToast("构建失败 ： " + apAdError.getMsg());

            }

            @Override
            public void onAPAdSplashPresentSuccess(APAdSplash apAdSplash) {
                showToast("展示成功");
                hideView();
            }

            @Override
            public void onAPAdSplashPresentFail(APAdSplash apAdSplash, APAdError apAdError) {
                Log.e(TAG, "展示失败：" + apAdError.getCode() + ",msg:" + apAdError.getMsg());
                showToast("展示失败 ： " + apAdError.getMsg());

            }

            @Override
            public void onAPAdSplashClick(APAdSplash apAdSplash) {
                Log.e(TAG, "点击了开屏");
            }

            @Override
            public void onAPAdSplashDidPresentLanding(APAdSplash apAdSplash) {
                showToast("打开landingPage");

            }

            @Override
            public void onAPAdSplashDidDismissLanding(APAdSplash apAdSplash) {
                showToast("关闭landingPage");

            }

            @Override
            public void onAPAdSplashApplicationWillEnterBackground(APAdSplash apAdSplash) {
                showToast("跳出应用");

            }

            @Override
            public void onAPAdSplashDismiss(APAdSplash apAdSplash) {
                showToast("开屏展示完成，关闭");
                showView();
            }

            @Override
            public void onAPAdSplashPresentTimeLeft(long l) {
                // 如果自定义跳过按钮可以在此设置获取倒计时
            }
        });

        splash.setDeeplinkTipWithTitle("Splash DeepLink Title");
        // 设置开屏背景（二选一）
        // 方式一 设置颜色
        splash.setSplashBackgroundColor(Color.parseColor("#cdcdcd"));
        // 方式二 设置图片
//        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
//        splash.setSplashBackgroundColor(bitmap);
        // 自定义开屏最大加载时长（秒）
        splash.setSplashMaxLoadInterval(SPLASH_TIME_OUT);
        // 自定义开屏展示时长(秒)
        splash.setSplashShowInterval(SPLASH_SHOW_INTERVAL);

        // 设置开屏的bottom视图
        splash.setSplashBottomLayoutView(bottomView, isAutofit);
        // 自定义开屏的跳过按钮
//        splash.setSplashCloseButtonView();
        // 设置开屏跳过按钮的位置
//        splash.setSplashCloseButtonPosition();


        if (isLoadAndPresentMode) {
            splash.loadAndPresentWithViewContainer(splashContainer);
        } else {
            splash.load();
        }

    }

    private void hideView() {
        rgModes.setVisibility(View.GONE);
        loadBtn.setVisibility(View.GONE);
        cb.setVisibility(View.GONE);
        if (isGetViewMode || isPresentMode) {
            showBtn.setVisibility(View.GONE);
        }
    }

    private void showView() {
        splashContainer.removeAllViews();
        rgModes.setVisibility(View.VISIBLE);
        cb.setVisibility(View.VISIBLE);
        if (isLoadAndPresentMode) {
            loadBtn.setVisibility(View.VISIBLE);
        }
        if (isGetViewMode) {
            loadBtn.setVisibility(View.VISIBLE);
            showBtn.setVisibility(View.VISIBLE);

        }
        if (isPresentMode) {
            loadBtn.setVisibility(View.VISIBLE);
            showBtn.setVisibility(View.VISIBLE);

        }
    }

    private void showSplash() {
        if (isPresentMode) {
            splash.presentWithViewContainer(splashContainer);
        } else if (isGetViewMode) {
            View view = splash.getSplashView();
            if (view != null) {
                splashContainer.removeAllViews();
                splashContainer.addView(view);
            }
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (splash != null) {
            splash.onDestroy();
        }
    }

    private boolean isLoadAndPresentMode = true;
    private boolean isPresentMode = false;
    private boolean isGetViewMode = false;

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId) {
            case R.id.mode1:
                showBtn.setVisibility(View.GONE);
                isLoadAndPresentMode = true;
                isGetViewMode = false;
                isPresentMode = false;
                break;
            case R.id.mode2:
                showBtn.setVisibility(View.VISIBLE);
                isGetViewMode = true;
                isPresentMode = false;
                isLoadAndPresentMode = false;
                break;
            case R.id.mode3:
                showBtn.setVisibility(View.VISIBLE);
                isPresentMode = true;
                isGetViewMode = false;
                isLoadAndPresentMode = false;
                break;
        }
    }

    private void showToast(String msg) {
        Toast.makeText(this, "" + msg, Toast.LENGTH_SHORT).show();
    }
}
