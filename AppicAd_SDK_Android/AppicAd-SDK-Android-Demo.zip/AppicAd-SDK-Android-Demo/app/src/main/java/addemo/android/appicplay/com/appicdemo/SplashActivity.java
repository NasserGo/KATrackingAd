package addemo.android.appicplay.com.appicdemo;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.ap.android.trunk.sdk.ad.listener.APAdSplashListener;
import com.ap.android.trunk.sdk.ad.splash.APAdSplash;
import com.ap.android.trunk.sdk.ad.utils.APAdError;

import org.w3c.dom.Text;

import addemo.android.appicplay.com.appicdemo.utils.DemoHelper;


public class SplashActivity extends Activity implements View.OnClickListener, RadioGroup.OnCheckedChangeListener {

    private static final String TAG = "SplashActivity";

    private APAdSplash splash;
    private Button loadBtn;
    private Button showBtn;
    private RadioGroup rgModes;
    private CheckBox cb;
    private LinearLayout splashContainer;
    private View bottomView;
    private static final int SPLASH_TIME_OUT = 10; // 秒
    private static final int SPLASH_SHOW_INTERVAL = 5; // 秒
    private boolean isAutofit = true;
    private Button skipBtn;

    private boolean isLeft,isRight,isTop,isBottom;
    private CheckBox leftCb,rightCb,topCb,bottomCb;
    private EditText leftEt,rightEt,topEt,bottomEt;
    private LinearLayout pointView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DemoHelper.setFullScreen(this);
        setContentView(R.layout.splash);
        initView();
    }


    private void initView() {
        splashContainer = findViewById(R.id.splashContainer);
        bottomView = getLayoutInflater().inflate(R.layout.splash_bottom, null);
        loadBtn = findViewById(R.id.load);
        showBtn = findViewById(R.id.show);
        skipBtn = findViewById(R.id.skipBtn);
        showBtn.setEnabled(false);
        rgModes = findViewById(R.id.rgModes);
        cb = findViewById(R.id.autofit);
        // 位置测试
        leftCb = findViewById(R.id.leftCb);
        rightCb = findViewById(R.id.rightCb);
        topCb = findViewById(R.id.topCb);
        bottomCb = findViewById(R.id.bottomCb);
        leftEt = findViewById(R.id.leftEt);
        rightEt = findViewById(R.id.rightEt);
        topEt = findViewById(R.id.topEt);
        bottomEt = findViewById(R.id.bottomEt);
        pointView = findViewById(R.id.pointView);

        pointView.setVisibility(View.VISIBLE);


        loadBtn.setOnClickListener(this);
        showBtn.setOnClickListener(this);
        rgModes.setOnCheckedChangeListener(this);
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                isAutofit = isChecked;
            }
        });


        leftCb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                isLeft = isChecked;
            }
        });

        rightCb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                isRight = isChecked;
            }
        });

        topCb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                isTop = isChecked;
            }
        });

        bottomCb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                isBottom = isChecked;
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.load:
                loadSplash();
                break;
            case R.id.show:
                showSplash();
                break;
        }
    }


    private void loadSplash() {
        loadBtn.setEnabled(false);
        if (splash != null) {
            splash = null;
            splashContainer.removeAllViews();
        }
        final TextView textView = new TextView(this);
        textView.setTextSize(30);
        textView.setTextColor(Color.parseColor("#ffffff"));
        splash = new APAdSplash(Config.SPLASH_SLOT_ID, new APAdSplashListener() {
            @Override
            public void onAPAdSplashLoadSuccess(APAdSplash ad) {
                Log.d(TAG, "开屏广告加载成功");
                showToast("开屏广告加载成功");
                if (!isLoadAndPresentMode) {
                    showBtn.setEnabled(true);
                }
            }

            @Override
            public void onAPAdSplashLoadFail(APAdSplash apAdSplash, APAdError apAdError) {
                Log.e(TAG, "加载失败：" + apAdError.getCode() + ",msg:" + apAdError.getMsg());
                showToast("加载失败 ： " + apAdError.getMsg());

                loadBtn.setEnabled(true);

            }

            @Override
            public void onAPAdSplashDidAssembleViewFail(APAdSplash apAdSplash, APAdError apAdError) {
                Log.e(TAG, "构建失败：" + apAdError.getCode() + ",msg:" + apAdError.getMsg());
                showToast("构建失败 ： " + apAdError.getMsg());

            }

            @Override
            public void onAPAdSplashPresentSuccess(APAdSplash apAdSplash) {
                showToast("展示成功");
                hideView();
            }

            @Override
            public void onAPAdSplashPresentFail(APAdSplash apAdSplash, APAdError apAdError) {
                Log.e(TAG, "展示失败：" + apAdError.getCode() + ",msg:" + apAdError.getMsg());
                showToast("展示失败 ： " + apAdError.getMsg());

            }

            @Override
            public void onAPAdSplashClick(APAdSplash apAdSplash) {
                Log.d(TAG, "点击了开屏");
            }

            @Override
            public void onAPAdSplashDidPresentLanding(APAdSplash apAdSplash) {
                showToast("打开landingPage");

            }

            @Override
            public void onAPAdSplashDidDismissLanding(APAdSplash apAdSplash) {
                showToast("关闭landingPage");

            }

            @Override
            public void onAPAdSplashApplicationWillEnterBackground(APAdSplash apAdSplash) {
                showToast("跳出应用");

            }

            @Override
            public void onAPAdSplashDismiss(APAdSplash apAdSplash) {
                showToast("开屏展示完成，关闭");
                showView();
                loadBtn.setEnabled(true);
            }

            @Override
            public void onAPAdSplashPresentTimeLeft(long l) {
                // 如果自定义跳过按钮可以在此设置获取倒计时
                Log.d(TAG,"onAPAdSplashPresentTimeLeft : "+l);
//                textView.setText(((l - 200) / 1000 + 1) + "");
                skipBtn.setText(((l - 200) / 1000 + 1) + "");
            }
        });

//        splash.setDeeplinkTipWithTitle("Splash DeepLink Title");
        // 设置开屏背景（二选一）
        // 方式一 设置颜色
        splash.setSplashBackgroundColor(Color.parseColor("#cdcdcd"));
        // 方式二 设置图片
//        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
//        splash.setSplashBackgroundColor(bitmap);
        // 自定义开屏最大加载时长（秒）
        splash.setSplashMaxLoadInterval(SPLASH_TIME_OUT);
        // 自定义开屏展示时长(秒)
        splash.setSplashShowInterval(SPLASH_SHOW_INTERVAL);


        // 设置开屏的bottom视图
        splash.setSplashBottomLayoutView(bottomView, isAutofit);

        try {
            if (skipBtn.getParent() != null){
                ViewGroup v = (ViewGroup) skipBtn.getParent();
                v.removeView(skipBtn);
            }
        }catch (Exception e){
            Log.e(TAG,"",e);
        }

        skipBtn.setVisibility(View.VISIBLE);
        // 自定义开屏的跳过按钮
        splash.setSplashCloseButtonView(skipBtn);


        // 设置位置
        int leftMargin = leftEt.getText().toString().equals("") ? 0 : Integer.parseInt(leftEt.getText().toString());
        int rightMargin = rightEt.getText().toString().equals("") ? 0 : Integer.parseInt(rightEt.getText().toString());
        int topMargin = topEt.getText().toString().equals("") ? 0 : Integer.parseInt(topEt.getText().toString());
        int bottomMargin = bottomEt.getText().toString().equals("") ? 0 : Integer.parseInt(bottomEt.getText().toString());



        // 设置开屏跳过按钮的位置
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        if (isLeft && isTop){
            params.gravity = Gravity.LEFT| Gravity.TOP;
        }else if (isLeft && isBottom){
            params.gravity = Gravity.LEFT | Gravity.BOTTOM;
        }else if (isRight && isTop){
            params.gravity = Gravity.RIGHT| Gravity.TOP;
        }else if (isRight && isBottom){
            params.gravity = Gravity.RIGHT | Gravity.BOTTOM;
        }else{
            params.gravity = Gravity.TOP| Gravity.RIGHT;
        }


        params.leftMargin = leftMargin;
        params.rightMargin = rightMargin;
        params.topMargin = topMargin;
        params.bottomMargin = bottomMargin;
        splash.setSplashCloseButtonPosition(params);

        if (isLoadAndPresentMode) {
            splash.loadAndPresentWithViewContainer(splashContainer);
        } else {
            splash.load();
            splash.setDeeplinkTipWithTitle("Splash DeepLink Title");
        }

    }

    private void hideView() {
        rgModes.setVisibility(View.GONE);
        loadBtn.setVisibility(View.GONE);
        pointView.setVisibility(View.GONE);
        cb.setVisibility(View.GONE);
        if (isGetViewMode || isPresentMode) {
            showBtn.setVisibility(View.GONE);
        }
    }

    private void showView() {
        splashContainer.removeAllViews();
        rgModes.setVisibility(View.VISIBLE);
        cb.setVisibility(View.VISIBLE);
        if (isLoadAndPresentMode) {
            loadBtn.setVisibility(View.VISIBLE);
            pointView.setVisibility(View.VISIBLE);
        }
        if (isGetViewMode) {
            loadBtn.setVisibility(View.VISIBLE);
            showBtn.setVisibility(View.VISIBLE);

        }
        if (isPresentMode) {
            loadBtn.setVisibility(View.VISIBLE);
            showBtn.setVisibility(View.VISIBLE);

        }
    }

    private void showSplash() {
        showBtn.setEnabled(false);
        if (isPresentMode) {
            splash.presentWithViewContainer(splashContainer);
        } else if (isGetViewMode) {

            View view = splash.getSplashView();
//            ViewGroup parentViewGroup = (ViewGroup) view.getParent();
//            if (parentViewGroup != null) {
//                parentViewGroup.removeView(view);
//            }
            if (view != null) {
                splashContainer.removeAllViews();
                splashContainer.addView(view);
            }
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (splash != null) {
            splash.destroy();
        }
    }

    private boolean isLoadAndPresentMode = true;
    private boolean isPresentMode = false;
    private boolean isGetViewMode = false;

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId) {
            case R.id.mode1:
                showBtn.setVisibility(View.GONE);
                pointView.setVisibility(View.VISIBLE);
                isLoadAndPresentMode = true;
                isGetViewMode = false;
                isPresentMode = false;
                break;
            case R.id.mode2:
                showBtn.setVisibility(View.VISIBLE);
                pointView.setVisibility(View.GONE);
                isGetViewMode = true;
                isPresentMode = false;
                isLoadAndPresentMode = false;
                break;
            case R.id.mode3:
                showBtn.setVisibility(View.VISIBLE);
                pointView.setVisibility(View.GONE);
                isPresentMode = true;
                isGetViewMode = false;
                isLoadAndPresentMode = false;
                break;
        }
    }

    private void showToast(String msg) {
        Toast.makeText(this, "" + msg, Toast.LENGTH_SHORT).show();
    }
}
