package addemo.android.appicplay.com.appicdemo;


public class Config {

    public static final String APP_INFO_ID = "qXvbPemZQrAYWZwp-6rmezr";
    public static final String NATIVE_SLOT_ID = "rGoJqMye";
    public static final String SPLASH_SLOT_ID = "KGYkDpmE";
    public static final String BANNER_SLOT_ID = "PmPeMxyq";
    public static final String INTERSTITIAL_SLOT_ID = "ZAaEDrAY";
    public static final String REWARD_VIDEO_SLOT_ID = "wAbWDJmZ";


}
