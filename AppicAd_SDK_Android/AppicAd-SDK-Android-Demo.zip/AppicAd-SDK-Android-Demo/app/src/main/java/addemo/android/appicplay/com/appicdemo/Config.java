package addemo.android.appicplay.com.appicdemo;


public class Config {

    public static final String APP_INFO_ID = "NeBkPmNNwVmlQpjx-y9Z13r";
    public static final String NATIVE_SLOT_ID = "lmdLdbmq";
    public static final String SPLASH_SLOT_ID = "wybloPAZ";
    public static final String BANNER_SLOT_ID = "";
    public static final String INTERSTITIAL_SLOT_ID = "";


}
