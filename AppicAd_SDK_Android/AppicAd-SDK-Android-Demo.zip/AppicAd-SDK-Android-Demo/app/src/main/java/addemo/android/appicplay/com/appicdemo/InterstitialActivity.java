package addemo.android.appicplay.com.appicdemo;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.ap.android.trunk.sdk.ad.interstitial.APAdInterstitial;
import com.ap.android.trunk.sdk.ad.listener.APAdInterstitialListener;
import com.ap.android.trunk.sdk.ad.utils.APAdError;

public class InterstitialActivity extends Activity implements View.OnClickListener {

    private static final String TAG = "InterstitialActivity";

    Button loadBtn;
    Button showBtn;

    private APAdInterstitial apInterstitial;
    private CheckBox muteCb;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.interstitial);


        loadBtn = findViewById(R.id.load);
        showBtn = findViewById(R.id.show);
        muteCb = findViewById(R.id.muteCb);
        muteCb.setVisibility(View.GONE);
        loadBtn.setEnabled(true);
        showBtn.setEnabled(false);

        findViewById(R.id.load).setOnClickListener(this);
        findViewById(R.id.show).setOnClickListener(this);
        muteCb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (apInterstitial != null) {
                    Log.d(TAG, "onCheckedChanged: " + isChecked);
                    apInterstitial.setMute(isChecked);
                } else {
                    Toast.makeText(InterstitialActivity.this, "请先load广告", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }


    private void load() {

        loadBtn.setEnabled(false);
        showBtn.setEnabled(false);

        if (apInterstitial != null) {
            apInterstitial.destroy();
            apInterstitial = null;
        }

        apInterstitial = new APAdInterstitial(Config.INTERSTITIAL_SLOT_ID, new APAdInterstitialListener() {
            @Override
            public void onApAdInterstitialLoadSuccess(APAdInterstitial ad) {
                Log.d(TAG, "onApAdInterstitialLoadSuccess: ");
                showBtn.setEnabled(true);
                muteCb.setVisibility(View.VISIBLE);
            }

            @Override
            public void onApAdInterstitialLoadFail(APAdInterstitial ad, APAdError err) {
                Log.e(TAG, "onApAdInterstitialLoadFail: " + err.getMsg());
                loadBtn.setEnabled(true);
            }

            @Override
            public void onApAdInterstitialPresentSuccess(APAdInterstitial ad) {
                Log.d(TAG, "onApAdInterstitialPresentSuccess: ");
            }

            @Override
            public void onApAdInterstitialPresentFail(APAdInterstitial ad, APAdError err) {
                Log.e(TAG, "onApAdInterstitialPresentFail: " + err.getMsg());
            }

            @Override
            public void onApAdInterstitialClick(APAdInterstitial ad) {
                Log.d(TAG, "onApAdInterstitialClick: ");
            }

            @Override
            public void onApAdInterstitialDidPresentLanding(APAdInterstitial ad) {
                Log.d(TAG, "onApAdInterstitialDidPresentLanding: ");
            }

            @Override
            public void onApAdInterstitialDidDismissLanding(APAdInterstitial ad) {
                Log.d(TAG, "onApAdInterstitialDidDismissLanding: ");
            }

            @Override
            public void onApAdInterstitialApplicationWillEnterBackground(APAdInterstitial ad) {
                Log.d(TAG, "onApAdInterstitialApplicationWillEnterBackground: ");
            }

            @Override
            public void onAPAdInterstitialDismiss(APAdInterstitial ad) {
                Log.d(TAG, "onAPAdInterstitialDismiss: ");
                loadBtn.setEnabled(true);
                showBtn.setEnabled(false);
                muteCb.setChecked(false);
                muteCb.setVisibility(View.GONE);
            }
        });
        apInterstitial.load();
    }



    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.load:
                loadBtn.setEnabled(false);
                showBtn.setEnabled(false);

                load();
                break;
            case R.id.show:
                showBtn.setEnabled(false);
                if (apInterstitial != null) {
                    apInterstitial.presentWithActivity(this);
                    loadBtn.setEnabled(true);
                }

                apInterstitial.setDeeplinkTipWithTitle("我是插屏测试");

                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (apInterstitial != null) {
            apInterstitial.destroy();
        }
    }

}
