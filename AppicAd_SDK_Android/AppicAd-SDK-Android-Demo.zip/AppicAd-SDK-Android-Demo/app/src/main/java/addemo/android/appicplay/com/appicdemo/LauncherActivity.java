package addemo.android.appicplay.com.appicdemo;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Message;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.ap.android.trunk.sdk.ad.listener.APAdSplashListener;
import com.ap.android.trunk.sdk.ad.splash.APAdSplash;
import com.ap.android.trunk.sdk.ad.utils.APAdError;
import com.ap.android.trunk.sdk.core.utils.LogUtils;

import addemo.android.appicplay.com.appicdemo.utils.DemoHelper;
import addemo.android.appicplay.com.appicdemo.utils.WeakHandler;


public class LauncherActivity extends Activity implements WeakHandler.IHandler {

    private static final String TAG = "LauncherActivity";

    APAdSplash splash;

    private static final int SPLASH_TIME_OUT = 10; // 秒
    private static final int MSG_GOTO_MAIN = 1000;
    private static final int SPLASH_SHOW_INTERVAL = 5;

    private WeakHandler handler = new WeakHandler(this);
    private LinearLayout adContainer;
    private boolean isLoaded;

    @Override

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DemoHelper.setFullScreen(this);
        setContentView(R.layout.launcher);
        LogUtils.logSwitch(true); // 开启日志
        adContainer = findViewById(R.id.adContainer);
        handler.sendEmptyMessageDelayed(MSG_GOTO_MAIN, (SPLASH_TIME_OUT * 1000));
        loadSplash();

    }

    private void loadSplash() {

        if (splash != null) {
            splash = null;
            adContainer.removeAllViews();
        }

        splash = new APAdSplash(Config.SPLASH_SLOT_ID, new APAdSplashListener() {
            @Override
            public void onAPAdSplashLoadSuccess(APAdSplash ad) {
                Log.d(TAG, "开屏广告加载成功");
                isLoaded = true;
                handler.removeCallbacksAndMessages(null);
                if (ad == null) {
                    return;
                }
                View view = ad.getSplashView();
                if (view != null) {
                    adContainer.removeAllViews();
                    adContainer.addView(view);
                } else {
                    gotoMain();
                }
            }

            @Override
            public void onAPAdSplashLoadFail(APAdSplash apAdSplash, APAdError apAdError) {
                Log.e(TAG, "加载失败：" + apAdError.getCode() + ",msg:" + apAdError.getMsg());
                showToast("加载失败 ： " + apAdError.getMsg());
                isLoaded = true;
                gotoMain();

            }

            @Override
            public void onAPAdSplashDidAssembleViewFail(APAdSplash apAdSplash, APAdError apAdError) {
                Log.e(TAG, "构建失败：" + apAdError.getCode() + ",msg:" + apAdError.getMsg());
                showToast("构建失败 ： " + apAdError.getMsg());
                isLoaded = true;
                gotoMain();

            }

            @Override
            public void onAPAdSplashPresentSuccess(APAdSplash apAdSplash) {
                showToast("展示成功");

            }

            @Override
            public void onAPAdSplashPresentFail(APAdSplash apAdSplash, APAdError apAdError) {
                Log.e(TAG, "展示失败：" + apAdError.getCode() + ",msg:" + apAdError.getMsg());
                showToast("展示失败 ： " + apAdError.getMsg());
                isLoaded = true;
                gotoMain();

            }

            @Override
            public void onAPAdSplashClick(APAdSplash apAdSplash) {
                Log.e(TAG, "点击了开屏");
            }

            @Override
            public void onAPAdSplashDidPresentLanding(APAdSplash apAdSplash) {
                showToast("打开landingPage");

            }

            @Override
            public void onAPAdSplashDidDismissLanding(APAdSplash apAdSplash) {
                showToast("关闭landingPage");

            }

            @Override
            public void onAPAdSplashApplicationWillEnterBackground(APAdSplash apAdSplash) {
                showToast("跳出应用");

            }

            @Override
            public void onAPAdSplashDismiss(APAdSplash apAdSplash) {
                showToast("开屏展示完成，关闭");
                gotoMain();
            }

            @Override
            public void onAPAdSplashPresentTimeLeft(long l) {
                // 如果自定义跳过按钮可以在此设置获取倒计时
            }
        });

        splash.setDeeplinkTipWithTitle("Launcher DeepLink Title");
        // 设置开屏背景（二选一）
        // 方式一 设置颜色
        splash.setSplashBackgroundColor(Color.parseColor("#cdcdcd"));
        // 方式二 设置图片
//        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
//        splash.setSplashBackgroundColor(bitmap);
        // 自定义开屏最大加载时长（秒）
        splash.setSplashMaxLoadInterval(SPLASH_TIME_OUT);
        // 自定义开屏展示时长(秒)
        splash.setSplashShowInterval(SPLASH_SHOW_INTERVAL);
        // 设置开屏的bottom视图
//        splash.setSplashBottomLayoutView();
        // 自定义开屏的跳过按钮
//        splash.setSplashCloseButtonView();
        // 设置开屏跳过按钮的位置
//        splash.setSplashCloseButtonPosition();
        /**
         * 加载开屏广告
         */
        splash.load();
    }


    private void gotoMain() {
        adContainer.removeAllViews();
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void showToast(String msg) {
        Toast.makeText(this, "" + msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void handleMsg(Message msg) {
        if (msg.arg1 == MSG_GOTO_MAIN) {
            if (!isLoaded) { // 超时跳转MainActivity
                gotoMain();
            }
        }
    }
}
