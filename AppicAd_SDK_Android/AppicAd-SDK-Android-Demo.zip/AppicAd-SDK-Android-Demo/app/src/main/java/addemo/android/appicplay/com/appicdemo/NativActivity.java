package addemo.android.appicplay.com.appicdemo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ap.android.trunk.sdk.ad.listener.APAdNativeExpressListener;
import com.ap.android.trunk.sdk.ad.listener.APAdNativeExpressVideoViewListener;
import com.ap.android.trunk.sdk.ad.nativ.APAdNativeExpress;
import com.ap.android.trunk.sdk.ad.nativ.APAdNativeExpressVideoState;
import com.ap.android.trunk.sdk.ad.nativ.APAdNativeExpressVideoView;
import com.ap.android.trunk.sdk.ad.utils.APAdError;

import java.text.SimpleDateFormat;
import java.util.Date;

public class NativActivity extends Activity {

    private static final String TAG = "NativActivity";

    private APAdNativeExpress nativeExpress;

    private Button loadBtn;
    private Button showBtn;
    private ViewGroup adContainer;

    public static String formatTime(long time) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String timeStr = "<" + simpleDateFormat.format(new Date(time)) + ">";
        return timeStr;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nativ);
        initView();


    }

    private void initView() {
        adContainer = this.findViewById(R.id.adContainer);
        loadBtn = findViewById(R.id.load);
        showBtn = findViewById(R.id.show);
        showBtn.setEnabled(false);
        loadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                load();
            }
        });
        showBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                show();
            }
        });
    }


    private void load() {

        Log.v(TAG, "开始进行原生广告load...");
//        loadBtn.setEnabled(false);
        if (this.nativeExpress != null) {
            nativeExpress = null;
            adContainer.removeAllViews();
        }

        nativeExpress = new APAdNativeExpress(Config.NATIVE_SLOT_ID, new APAdNativeExpressListener() {
            @Override
            public void onApAdNativeExpressDidLoadSuccess(APAdNativeExpress apAdNativeExpress) {
                showToast("原生广告加载成功");
                showBtn.setEnabled(true);
            }

            @Override
            public void onApAdNativeExpressDidLoadFail(APAdNativeExpress apAdNativeExpress, APAdError apAdError) {
                showToast("原生广告加载失败：" + apAdError.getMsg());
                Log.e(TAG, "原生广告加载失败：" + apAdError.getCode() + ", msg : " + apAdError.getMsg());
                loadBtn.setEnabled(true);
            }

            @Override
            public void onApAdNativeExpressDidClick(APAdNativeExpress apAdNativeExpress) {
                Log.e(TAG, "点击了原生广告");
                showToast("点击了原生广告");

            }

            @Override
            public void onApAdNativeExpressDidPresentLanding(APAdNativeExpress apAdNativeExpress) {
                Log.d(TAG, "展示landingpage");
                showToast("展示landingpage");

            }

            @Override
            public void onApAdNativeExpressDidDismissLanding(APAdNativeExpress apAdNativeExpress) {
                Log.d(TAG, "关闭landingpage");
                showToast("关闭landingpage");

            }

            @Override
            public void onApAdNativeExpressApplicationWillEnterBackground(APAdNativeExpress apAdNativeExpress) {
                Log.d(TAG, "跳出应用");
                showToast("跳出应用");
            }
        });
        nativeExpress.setDeeplinkTipWithTitle("Native DeepLink Title");

        nativeExpress.load();
    }

    private void show() {
        try {
            adContainer.removeAllViews();
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            linearLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            APAdNativeExpressVideoView nativeExpressVideoView = nativeExpress.getAPAdVideo();
            if (nativeExpressVideoView != null) { // 展示视频广告
                nativeExpressVideoView.setApAdNativeExpressVideoViewListener(new APAdNativeExpressVideoViewListener() {
                    @Override
                    public void onAPAdNativeExpressVideoViewDidPlayFinish(APAdNativeExpressVideoView ad) {
                        Log.d(TAG, "视频播放完成");
                        showToast("视频播放完成");

                    }
                });
                linearLayout.addView(nativeExpressVideoView);
            } else {
                ImageView screenshot = new ImageView(this);
                screenshot.setLayoutParams(new LinearLayout.LayoutParams(300, 300));
                if (nativeExpress.getAPAdScreenshot() != null) {
                    screenshot.setImageBitmap(nativeExpress.getAPAdScreenshot());
                } else {
                    screenshot.setImageResource(R.mipmap.ic_launcher);
                }
                ImageView icon = new ImageView(this);
                icon.setLayoutParams(new LinearLayout.LayoutParams(150, 150));
                if (nativeExpress.getAPAdIcon() != null) {
                    icon.setImageBitmap(nativeExpress.getAPAdIcon());
                } else {
                    icon.setImageResource(R.mipmap.ic_launcher);
                }

                TextView title = new TextView(this);
                title.setText(nativeExpress.getAPAdTitle());
                TextView desc = new TextView(this);
                desc.setText(nativeExpress.getAPAdDescription());
                linearLayout.addView(title);
                linearLayout.addView(desc);
                linearLayout.addView(icon);
                linearLayout.addView(screenshot);
            }

            adContainer.addView(linearLayout);
            nativeExpress.registerContainerView(adContainer);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void showToast(String msg) {
        Toast.makeText(this, "" + msg, Toast.LENGTH_SHORT).show();
    }

}
