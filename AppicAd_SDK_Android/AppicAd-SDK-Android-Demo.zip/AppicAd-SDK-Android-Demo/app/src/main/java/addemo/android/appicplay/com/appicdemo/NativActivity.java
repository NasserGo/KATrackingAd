package addemo.android.appicplay.com.appicdemo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ap.android.trunk.sdk.ad.listener.APAdNativeListener;
import com.ap.android.trunk.sdk.ad.listener.APAdNativeVideoViewListener;
import com.ap.android.trunk.sdk.ad.nativ.APAdNative;
import com.ap.android.trunk.sdk.ad.nativ.APAdNativeVideoState;
import com.ap.android.trunk.sdk.ad.nativ.APAdNativeVideoView;
import com.ap.android.trunk.sdk.ad.utils.APAdError;
import com.bumptech.glide.Glide;

import java.text.SimpleDateFormat;
import java.util.Date;

public class NativActivity extends Activity {

    private static final String TAG = "NativActivity";

    private APAdNative nativeExpress;

    private Button loadBtn;
    private Button showBtn;
    private ViewGroup adContainer;
    private Button pauseBtn, resumeBtn, muteBtn, unMuteBtn;
    private LinearLayout videoFunView;
    public static String formatTime(long time) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String timeStr = "<" + simpleDateFormat.format(new Date(time)) + ">";
        return timeStr;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nativ);
        initView();


    }

    private void initView() {
        adContainer = this.findViewById(R.id.adContainer);
        loadBtn = findViewById(R.id.load);
        showBtn = findViewById(R.id.show);
        showBtn.setEnabled(false);

        videoFunView = findViewById(R.id.videoFunView);
        pauseBtn = findViewById(R.id.pause);
        resumeBtn = findViewById(R.id.resume);
        muteBtn = findViewById(R.id.mute);
        unMuteBtn = findViewById(R.id.unmute);

        loadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadBtn.setEnabled(false);
                load();
            }
        });
        showBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                show();
            }
        });
    }


    private void load() {

        Log.v(TAG, "开始进行原生广告load...");
//        loadBtn.setEnabled(false);
        if (this.nativeExpress != null) {
            nativeExpress = null;
            adContainer.removeAllViews();
        }

        nativeExpress = new APAdNative(Config.NATIVE_SLOT_ID, new APAdNativeListener() {
            @Override
            public void onApAdNativeDidLoadSuccess(APAdNative apAdNativeExpress) {
                showToast("原生广告加载成功");
                showBtn.setEnabled(true);
            }

            @Override
            public void onApAdNativeDidLoadFail(APAdNative apAdNative, APAdError apAdError) {
                showToast("原生广告加载失败：" + apAdError.getMsg());
                Log.e(TAG, "原生广告加载失败：" + apAdError.getCode() + ", msg : " + apAdError.getMsg());
                loadBtn.setEnabled(true);
            }

            @Override
            public void onApAdNativeDidClick(APAdNative apAdNativeExpress) {
                Log.d(TAG, "点击了原生广告");
                showToast("点击了原生广告");

            }

            @Override
            public void onApAdNativeDidPresentLanding(APAdNative apAdNativeExpress) {
                Log.d(TAG, "展示landingpage");
                showToast("展示landingpage");

            }

            @Override
            public void onApAdNativeDidDismissLanding(APAdNative apAdNativeExpress) {
                Log.d(TAG, "关闭landingpage");
                showToast("关闭landingpage");

            }

            @Override
            public void onApAdNativeApplicationWillEnterBackground(APAdNative apAdNativeExpress) {
                Log.d(TAG, "跳出应用");
                showToast("跳出应用");
            }
        });
        nativeExpress.setDeeplinkTipWithTitle("Native DeepLink Title");
        nativeExpress.load();
    }

    private void show() {
        try {
            showBtn.setEnabled(false);
            loadBtn.setEnabled(true);
            adContainer.removeAllViews();
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(LinearLayout.VERTICAL);
            linearLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            final APAdNativeVideoView nativeExpressVideoView = nativeExpress.getAPAdVideo();
            if (nativeExpressVideoView != null) { // 展示视频广告

                videoFunView.setVisibility(View.VISIBLE);
                pauseBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        nativeExpressVideoView.pause();
                        pauseBtn.setEnabled(false);
                        resumeBtn.setEnabled(true);
                    }
                });

                resumeBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        nativeExpressVideoView.play();
                        pauseBtn.setEnabled(true);
                        resumeBtn.setEnabled(false);
                    }
                });

                muteBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        nativeExpressVideoView.setMute(true);
                        muteBtn.setEnabled(false);
                        unMuteBtn.setEnabled(true);
                    }
                });

                unMuteBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        nativeExpressVideoView.setMute(false);
                        unMuteBtn.setEnabled(false);
                        muteBtn.setEnabled(true);
                    }
                });


                nativeExpressVideoView.setApAdNativeVideoViewListener(new APAdNativeVideoViewListener() {
                    @Override
                    public void onAPAdNativeVideoViewDidChangeState(APAdNativeVideoView apAdNativeVideoView, APAdNativeVideoState state) {
                        String stateMsg = state.getState() == 0 ? "播放失败" :
                                state.getState() == 2 ? "播放中" :
                                        state.getState() == 3 ? "播放完成" :
                                                state.getState() == 4 ? "播放暂停" : "";

                        Log.d(TAG, "视频状态：" + stateMsg);
                        Toast.makeText(NativActivity.this, "视频播放状态 ： " + stateMsg, Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onAPAdNativeVideoViewDidPlayFinish(APAdNativeVideoView ad) {
                        Log.d(TAG, "视频播放完成");
                        showToast("视频播放完成");
                        videoFunView.setVisibility(View.GONE);

                    }
                });
                linearLayout.addView(nativeExpressVideoView);
            } else {
                ImageView screenshot = new ImageView(this);
                screenshot.setLayoutParams(new LinearLayout.LayoutParams(300, 300));
                if (nativeExpress.getAPAdScreenshotUrl() != null) {
                    Glide.with(this).load(nativeExpress.getAPAdScreenshotUrl()).into(screenshot);
                } else {
                    screenshot.setImageResource(R.mipmap.ic_launcher);
                }
                ImageView icon = new ImageView(this);
                icon.setLayoutParams(new LinearLayout.LayoutParams(150, 150));
                if (nativeExpress.getAPAdIconUrl() != null) {
                    Glide.with(this).load(nativeExpress.getAPAdIconUrl()).into(icon);
                } else {
                    icon.setImageResource(R.mipmap.ic_launcher);
                }

                TextView title = new TextView(this);
                title.setText(nativeExpress.getAPAdTitle());
                TextView desc = new TextView(this);
                desc.setText(nativeExpress.getAPAdDescription());
                linearLayout.addView(title);
                linearLayout.addView(desc);
                linearLayout.addView(icon);
                linearLayout.addView(screenshot);
            }

            adContainer.addView(linearLayout);
            nativeExpress.registerContainerView(adContainer);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void showToast(String msg) {
        Toast.makeText(this, "" + msg, Toast.LENGTH_SHORT).show();
    }

}
