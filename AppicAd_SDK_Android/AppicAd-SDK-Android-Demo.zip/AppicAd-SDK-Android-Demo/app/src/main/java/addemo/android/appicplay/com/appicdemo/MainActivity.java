package addemo.android.appicplay.com.appicdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;

import com.ap.android.trunk.sdk.ad.APAD;
import com.ap.android.trunk.sdk.core.APSDK;
import com.ap.android.trunk.sdk.core.others.APAdError;
import com.ap.android.trunk.sdk.core.utils.APSDKListener;
import com.ap.android.trunk.sdk.core.utils.LogUtils;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        findViewById(R.id.permission).setOnClickListener(this);
        findViewById(R.id.banner).setOnClickListener(this);
        findViewById(R.id.nativ).setOnClickListener(this);
        findViewById(R.id.interstitial).setOnClickListener(this);
        findViewById(R.id.splash).setOnClickListener(this);
        findViewById(R.id.incentivized).setOnClickListener(this);
        // sdk 日志开关
        LogUtils.logSwitch(true);
        // 设置IMEI
        APSDK.setDeviceImei("123456789123456789");
        // 初始化SDK
        APSDK.init(this, Config.APP_INFO_ID, new APSDKListener() {
            @Override
            public void onSDKInitializeSuccess() {
                Log.v(TAG, "onSDKInitializeSuccess: " );
            }

            @Override
            public void onSDKInitializeFail(APAdError apAdError) {

            }
        });
        APSDK.setIsMobileNetworkDirectlyDownload(true);
    }

    @Override
    public void onClick(View view) {

        Intent intent = null;
        switch (view.getId()) {
            case R.id.nativ:
                intent = new Intent(MainActivity.this, NativActivity.class);
                break;
            case R.id.banner:
                intent = new Intent(MainActivity.this, BannerActivity.class);
                break;

            case R.id.interstitial:
                intent = new Intent(MainActivity.this, InterstitialActivity.class);
                break;

            case R.id.splash:
                intent = new Intent(MainActivity.this, SplashActivity.class);
                break;

            case R.id.incentivized:
                intent = new Intent(MainActivity.this, IncentivizedActivity.class);
                break;
            case R.id.permission:
                APSDK.requestSDKRequiredPermissions(this);
                return;

        }
        startActivity(intent);


    }
}
