package addemo.android.appicplay.com.appicdemo;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.ap.android.trunk.sdk.ad.listener.APAdRewardVideoListener;
import com.ap.android.trunk.sdk.ad.utils.APAdError;
import com.ap.android.trunk.sdk.ad.video.APAdRewardVideo;


public class IncentivizedActivity extends  Activity {

    private APAdRewardVideo rewardVideo;

    private static final String TAG = "IncentivizedActivity";
    private Button showBt;
    private Button loadBt;
    private CheckBox muteCb;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.video);
        loadBt = findViewById(R.id.load);
        showBt = findViewById(R.id.show);
        muteCb = findViewById(R.id.muteCb);
        loadBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                load();
            }
        });
        showBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                show();
            }
        });
        muteCb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (rewardVideo != null) {
                    Log.d(TAG, "onCheckedChanged: " + isChecked);
                    rewardVideo.setMute(isChecked);
                } else {
                    Toast.makeText(IncentivizedActivity.this, "请先load广告", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void load() {
        if (rewardVideo != null) {
            rewardVideo.destroy();
        }
        rewardVideo = new APAdRewardVideo(Config.REWARD_VIDEO_SLOT_ID, new APAdRewardVideoListener() {
            @Override
            public void onAPAdRewardVideoLoadSuccess(APAdRewardVideo ad) {
                Toast.makeText(IncentivizedActivity.this, "视频加载成功", Toast.LENGTH_LONG).show();
                Log.d(TAG, "onAPAdRewardVideoLoadSuccess: ");
                showBt.setEnabled(true);
                muteCb.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAPAdRewardVideoLoadFail(APAdRewardVideo ad, APAdError err) {
                Toast.makeText(IncentivizedActivity.this, "视频加载失败", Toast.LENGTH_LONG).show();
                loadBt.setEnabled(true);
                Log.e(TAG, "onAPAdRewardVideoLoadFail: " + err.getMsg());
            }

            @Override
            public void onAPAdRewardVideoPresentSuccess(APAdRewardVideo ad) {
                Log.d(TAG, "onAPAdRewardVideoPresentSuccess: ");
            }

            @Override
            public void onAPAdRewardVideoPresentFail(APAdRewardVideo ad, APAdError err) {
                Log.e(TAG, "onAPAdRewardVideoPresentFail: " + err.getMsg());
                loadBt.setEnabled(true);
            }

            @Override
            public void onAPAdRewardVideoClick(APAdRewardVideo ad) {
                Log.d(TAG, "onAPAdRewardVideoClick: ");
            }

            @Override
            public void onAPAdRewardVideoDidPlayComplete(APAdRewardVideo ad) {
                Log.d(TAG, "onAPAdRewardVideoDidPlayComplete: ");

            }

            @Override
            public void onAPAdRewardVideoDismiss(APAdRewardVideo ad) {
                Log.d(TAG, "onAPAdRewardVideoDismiss: ");
                loadBt.setEnabled(true);
                showBt.setEnabled(false);
                muteCb.setChecked(false);
                muteCb.setVisibility(View.GONE);
            }
        });
        rewardVideo.load();
        loadBt.setEnabled(false);

    }

    private void show() {
        if (rewardVideo.isReady()) {
            rewardVideo.presentWithViewContainer(this);
            rewardVideo.setDeeplinkTipWithTitle("我是激励视频测试");

        } else {
            Log.e(TAG, "show: video is not ready, show failed.");
        }
    }
}